"use strict";
/**
 * @ngdoc controller
 * @name loginModule.loginController
 * @requires $scope
 * @requires commonService.Navigation
 * @requires loginModule.AuthService
 * @requires $window
 * @restrict E
 * @description
 * loginController controls the login related activities.
 */
loginModule.controller('loginController', ['$scope', '$stateParams', 
    function ($scope, $stateParams) {

        alert('asdf');

        
    }
]);