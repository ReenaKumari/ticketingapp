var loginModule = angular.module('loginModule', []);

loginModule.config(['$stateProvider', '$urlRouterProvider', function($stateProvider , $urlRouterProvider) {
    $stateProvider
        .state('login', {
            url: '/login',
            templateUrl: 'templates/login.html',
            controller: 'loginController'
        });
        $urlRouterProvider.otherwise('/login');
}]);