'use strict';
appModule.controller('menuController', [
    '$scope', '$state', '$ionicPlatform', '$ionicHistory', 'Loading',
    '$rootScope', 'localStorageService', 'HelperService', 'AppConstant', 'ErrorService', 'AppConfig', '$ionicPopup', '$ionicModal',
    function ($scope, $state, $ionicPlatform, $ionicHistory, Loading,
        $rootScope, localStorageService, HelperService, AppConstant, ErrorService, AppConfig, $ionicPopup, $ionicModal) {
       
        // $scope.onHardwareBackButton = function (event) {
        //     if ($state.current.name === "app.dashboard") {
        //         ionic.Platform.exitApp();
        //     } else {
        //         $ionicHistory.goBack();
        //         event.preventDefault();
        //         event.stopPropagation();
        //     }
        // };



        // $ionicPlatform.registerBackButtonAction($scope.onHardwareBackButton, 101);

    }
]);
