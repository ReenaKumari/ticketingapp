var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');
var gulpif = require('gulp-if');
var concat = require('gulp-concat');
var sass = require('gulp-sass');
var minifyCss = require('gulp-minify-css');


gulp.task('sass', function(done) {
    gulp.src(conf.paths.sass)
        .pipe(sass())
        .pipe(gulpif(conf.options.mode === 'production', minifyCss({
            keepSpecialComments: 0
        })))
        .pipe(gulp.dest('./www/css/'))
        .on('end', done);
});

