var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var gulpif = require('gulp-if');
var sourcemaps = require('gulp-sourcemaps');

gulp.task('vendorjs', function(done) {
    return gulp.src([
            path.join(conf.paths.src, '/lib/external/ionic/js/ionic.bundle.js'),
            path.join(conf.paths.src, '/lib/external/angular-filter/dist/angular-filter.js'),
            path.join(conf.paths.src, '/lib/external/angular-ios9-uiwebview-patch/angular-ios9-uiwebview.patch.js'),
            path.join(conf.paths.src, '/lib/external/angular-local-storage/dist/angular-local-storage.js'),
            path.join(conf.paths.src, '/lib/external/ngCordova/dist/ng-cordova.js'),
            path.join(conf.paths.src, '/lib/external/angular-sanitize/angular-sanitize.js'),
        ])
        .pipe(gulpif(conf.options.mode === 'dev', sourcemaps.init()))
        .pipe(concat('vendor.js'))
        .pipe(gulpif(conf.options.mode === 'production', uglify()))
        .pipe(gulpif(conf.options.mode === 'dev', sourcemaps.write()))
        .pipe(gulp.dest('./www/lib/'));
});


gulp.task('scripts', function(done) {
    return gulp.src([
            path.join(conf.paths.src, '/**/*.module.js'),
            path.join(conf.paths.src, '/**/*.model.js'),
            path.join(conf.paths.src, '/**/*.service.js'),
            path.join(conf.paths.src, '/**/*.controller.js'),
            path.join(conf.paths.src, '/**/*.js'),
            path.join('!' + conf.paths.src, '/lib/external/**/*.js')
        ])
        .pipe(gulpif(conf.options.mode === 'dev', sourcemaps.init()))
        .pipe(concat('app.js'))
        .pipe(gulpif(conf.options.mode === 'production', uglify()))
        .pipe(gulpif(conf.options.mode === 'dev', sourcemaps.write()))
        .pipe(gulp.dest('./www/js/'));
});
