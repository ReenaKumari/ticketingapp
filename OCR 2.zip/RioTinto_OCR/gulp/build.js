var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');
var runSequence = require('run-sequence');
var shell = require('gulp-shell');

gulp.task('build', function (done) {
    runSequence('clean', 'fonts', 'images', 'data', 'database', 'sass', 'vendorjs', 'scripts', 'minify-html', 'inject', function () {
        done();
    });
});

gulp.task('serve', function (done) {
    runSequence('build', 'watch', 'webserver', function () {
        done();
    });
});

gulp.task('ionic-build-dev', shell.task([
  'gulp --mode dev',
  'ionic build'
]));

gulp.task('ionic-build', shell.task([
  'gulp',
  'ionic build'
]));


gulp.task('ionic-build-ios', shell.task([
  'gulp',
  'ionic build ios'
]));

gulp.task('ionic-run-ios', shell.task([
  'gulp',
  'ionic run ios'
]));

gulp.task('ionic-build-android', shell.task([
  'gulp',
  'ionic build android'
]));

gulp.task('ionic-run-android', shell.task([
  'gulp',
  'ionic run android'
]));