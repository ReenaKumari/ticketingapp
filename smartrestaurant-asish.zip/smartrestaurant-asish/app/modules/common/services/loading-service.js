commonService.service('Loading', function ($ionicLoading, $timeout) {
    this.show = function (message) {
        var loadmessage = message ? message : "Please wait..."
        $ionicLoading.show({
            noBackdrop: true,
            //templateUrl: 'templates/spinner.html'
            template: '<ion-spinner class="light"></ion-spinner>' +
                '<br /><span>' + loadmessage +
                '</span>'
        });

    };
    this.hide = function () {
        $ionicLoading.hide();
    };

    this.toggle = function () {
        var self = this;
        self.show();

        // wait for 3 seconds and hide the overlay
        $timeout(function () {
            self.hide();
        }, 5000);
    };

});