(function (angular) {
    'use strict';
    commonService.service('HelperService', ['$ionicPopup', '$state', '$cordovaNetwork', 'AppConstant','localStorageService',
        function ($ionicPopup, $state, $cordovaNetwork, AppConstant, localStorageService) {
            // check if online
            this.isOnline = function () {
                if (window.cordova) {
                    return $cordovaNetwork.isOnline();
                } else {
                    return navigator.onLine;
                }
            };

            this.showOneButtonPopup = function (option) {
                $ionicPopup.alert({
                    title: option.title,
                    template: option.body,
                    cssClass: 'custom-popup',
                    buttons: [
                        {
                            text: option.okButton || 'Ok',
                            type: 'button-positive',
                            onTap: option.onOk || angular.noop
                        }
                    ]
                });
            };
            this.getLastSyncInterval = function () {
                var me = this;
                var lastSync = localStorageService.get(AppConstant.LAST_SYNC_PUSH);
                console.log('last sync== '+lastSync);
                if (lastSync) {
                    var syncDatetime = new Date(lastSync).getTime();
                    var currentDatetime = new Date().getTime();
                    var hourDiff = currentDatetime - syncDatetime; //in ms
                    var minDiff = hourDiff / 60 / 1000; //in minutes
                    if (minDiff > AppConstant.SYNC_INTERVAL) {
                        return true; // true for start the sync
                    } else {
                        return false; // false for not to sync
                    }
                } else {
                    localStorageService.set(AppConstant.LAST_SYNC_PUSH, new Date().getTime());
                    return false;// true for start the sync
                }
            };

            this.showTwoButtonPopup = function (option) {
                $ionicPopup.confirm({
                    title: option.title,
                    template: option.body,
                    cssClass: 'custom-popup',
                    buttons: [
                        {
                            text: option.okButton || 'Ok',
                            type: 'button-positive',
                            onTap: option.onOk || angular.noop
                        },
                        {
                            text: option.cancelButton || 'Cancel',
                            type: 'button-negative',
                            onTap: option.onCancel || angular.noop
                        }
                    ]
                });
            };

            this.loadSignInPage = function () {
                var goToLogin = function (error) {
                    $state.go('login');
                },
                    me = this;
                function checkOnline(callBack) {
                    var online = window.cordova ? $cordovaNetwork.isOnline() : navigator.onLine;
                    if (!online) {
                        me.showOneButtonPopup({
                            title: "Connectivity Error",
                            body: "You are currently offline. Please connect to the network and retry.",
                        });
                        return;
                    }
                    callBack();
                }
                checkOnline(goToLogin);
            };
        }
    ]);
} (window.angular));
