'use strict';

//App specific configurations
appModule
    .constant('AppConfig', {
        name: 'OCR Accenture',
        version: '1.0',
        env: {
            mode: 'development' // static|development|production
        },
        configuration: {
            dateFormat: ['dd/MM/yyyy', 'MM-dd-yyyy'],
            settings: {
                sessionIdleTimeout: 15, //15 minutes
                sessionValidPINLoginAttempts: 4,
                sessionValidateInterval: 30000 //30 seconds
            }
        },
        viewStubs: {
            serviceReqPath: 'stubs/views/',
            authenticate: 'login.json',
            logout: 'logout.json'
        },
        api: {
            static: {
                serviceReqPath: 'stubs/',
                authenticate: 'login.json',
                readcycles: 'readcycle.json',
                readcycleproperties: 'Regions.json',
                SyncMeterDetails : 'SyncMeterDetails'
            },
            development: {
                serviceReqPath: 'https://test.com/cspmobileapi/odata/v1/'
                
            },
            production: {
                serviceReqPath: 'https://test.com/cspmobileapi/odata/v1/'
            }
        }
        
    });
