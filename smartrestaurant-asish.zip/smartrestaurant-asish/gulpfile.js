var gulp = require('gulp');
var bower = require('bower');
var concat = require('gulp-concat');
var sass = require('gulp-sass');
var minifyCss = require('gulp-minify-css');
var rename = require('gulp-rename');
var uglify = require('gulp-uglify');
var minifyHTML = require('gulp-minify-html');
var imagemin = require('gulp-imagemin');
var jshint = require('gulp-jshint');
var webserver = require('gulp-webserver');
var inject = require('gulp-inject')
var path = require('path');
var gulpif = require('gulp-if');
var rimraf = require('gulp-rimraf');
var runSequence = require('run-sequence');
var gulpDocs = require('gulp-ngdocs');
var shell = require('gulp-shell');


var wrench = require('wrench');
/**
 *  This will load all js or coffee files in the gulp directory
 *  in order to load all gulp tasks
 */
wrench.readdirSyncRecursive('./gulp').filter(function(file) {
    return (/\.(js|coffee)$/i).test(file);
}).map(function(file) {
    require('./gulp/' + file);
});



gulp.task('default', function() {
    gulp.start('build');
});
