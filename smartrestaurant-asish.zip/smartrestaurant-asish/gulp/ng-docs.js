var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');
var gulpDocs = require('gulp-ngdocs');


gulp.task('ngdocs', [], function() {
    var options = {
        html5Mode: false,
        startPage: '/api',
        title: "Jobs"
    }
    return gulpDocs.sections({
            api: {
                glob: ['./app/lib/internal/**/*.js', './app/*.js', './app/modules/**/*.js', './app/common/**/*.js'],
                api: true,
                title: 'API Reference'
            }
        }).pipe(gulpDocs.process(options))
        .pipe(gulp.dest('./docs'));
});
