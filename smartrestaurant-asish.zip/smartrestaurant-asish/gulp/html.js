var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');
var minifyHTML = require('gulp-minify-html');
var rename = require('gulp-rename');

gulp.task('minify-html', function () {
    var opts = {
        conditionals: true,
        spare: true
    };
    return gulp.src([
            conf.paths.html,
            path.join('!' + conf.paths.src, '/lib/**/*.html')
        ])
        .pipe(minifyHTML(opts))
        .pipe(rename({
            dirname: ''
        }))
        .pipe(gulp.dest('./www/templates/'));
});