var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');

var $ = require('gulp-load-plugins')();

gulp.task('clean', function () {
    return gulp.src([
            path.join(conf.paths.www)
        ], {
            read: false
        })
        .pipe($.rimraf());
});

gulp.task('fonts', function () {
    return gulp.src([
            path.join(conf.paths.src, '/lib/fonts/helveticaneue/*.*'),
            path.join(conf.paths.src, '/lib/external/ionic/fonts/ionicons.*')
        ])
        .pipe(gulp.dest('./www/fonts/'));
});

gulp.task('images', function () {
    return gulp.src(conf.paths.images)
        .pipe($.imagemin({
            optimizationLevel: 3,
            progressive: true,
            interlaced: true
        }))
        .pipe(gulp.dest('./www/img'));
});

gulp.task('data', function () {
    return gulp.src(conf.paths.data)
        .pipe(gulp.dest('./www/data'));
});

gulp.task('database', function () {
    return gulp.src([
        path.join(conf.paths.src, '*.db'),
        path.join(conf.paths.src, '*.sqlite')
        ])
        .pipe(gulp.dest('./www/'));
});