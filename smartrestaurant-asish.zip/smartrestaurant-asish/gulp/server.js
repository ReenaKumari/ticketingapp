var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');
var webserver = require('gulp-webserver');

gulp.task('webserver', function() {
    gulp.src('www')
        .pipe(webserver({
            port: 9000,
            livereload: false,
            directoryListing: false,
            open: true
        }));
});

