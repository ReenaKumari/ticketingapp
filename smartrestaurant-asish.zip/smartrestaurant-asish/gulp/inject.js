var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');
var inject = require('gulp-inject')


gulp.task('inject', function() {
    var injectStyles = gulp.src([
        path.join(conf.paths.www, 'css/*.css')
    ], {
        read: false
    });

    var injectScripts = gulp.src([
        path.join(conf.paths.www, 'lib/*.js'),
        path.join(conf.paths.www, 'js/*.js')
    ]);

    var injectOptions = {
        addRootSlash: false,
        relative: true
    };


   return gulp.src(path.join(conf.paths.src, '*.html'))
        .pipe(gulp.dest(conf.paths.www))
        .pipe(inject(injectStyles, injectOptions))
        .pipe(inject(injectScripts, injectOptions))
        .pipe(gulp.dest(conf.paths.www));
});
