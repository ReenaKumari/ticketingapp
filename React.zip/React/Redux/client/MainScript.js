import {connect} from 'react-redux';
import * as actions from './Actions/ActionCreaters';
import Main from './Components/Main';
import {bindActionCreators} from 'redux';

function mapStateToProps(storeData){
    return{
        myusers:storeData.users
    }
}

function mapDispatchToProps(dispatch){
    return bindActionCreators(actions,dispatch)
}

var App = connect(mapStateToProps,mapDispatchToProps)(Main);

export default App;