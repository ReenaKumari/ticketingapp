import React from 'react';

export default class Users extends React.Component{
    render(){
        console.log(this.props.myusers);
        var usersToBeCreated = this.props.myusers.map((user,index)=>{
            //return <li>{user.login}</li>
            return <div className="raj">
                <h2>{user.login}</h2>
                <img src = {user.avatar_url} height="100px" width="100px" className="nag"/>
                <input type="button" value={user.followers} className="btn btn-primary" onClick={this.props.addfollower.bind(null,index)}/>
                </div>
            
        })

        return <div>
            <h1>Github Users </h1>
            <ul>{usersToBeCreated }</ul>
            </div>
    }
}