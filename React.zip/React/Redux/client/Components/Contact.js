import React from 'react';

export default class Contact extends React.Component{
    render(){
        return <h1>Contact Component</h1>
    }
}