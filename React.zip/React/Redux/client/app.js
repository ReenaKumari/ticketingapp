// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import {Router,Route,IndexRoute,browserHistory} from 'react-router';
import {Provider} from 'react-redux';
import store from './Reducers/Store';

import Main from './Components/Main';
import Users from './Components/Users';
import Contact from './Components/Contact'
import App from './MainScript'

var router =<Provider store={store}>
    <Router history={browserHistory}>
                <Route path="/" component={App}>
                <IndexRoute component={Users}></IndexRoute>
                <Route path="/Contact" component={Contact}></Route>
                </Route>
             </Router>
             </Provider>

ReactDOM.render(router,document.getElementById("content"));