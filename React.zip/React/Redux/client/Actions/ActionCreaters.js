export function adduser(){
    return {type:'ADD_USER'};
}

export function addfollower(index){
    return {type:'ADD_FOLLOWER',index};
}