export default function contact(defStore=[],action){
    switch(action.type){
        case 'ADD_CONTACT':
        console.log('Contact Reducer..');
    }
//Logic for changing the store
return defStore;
} 