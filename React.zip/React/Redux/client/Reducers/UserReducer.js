export default function users(defStore=[],action){
   // console.log('User Reducer');
   //Logic for chaning the Store!
   switch(action.type){
       case 'ADD_FOLLOWER':
       var userindex = action.index;
       var newStore = [...defStore.slice(0,userindex),
        {...defStore[userindex],followers:defStore[userindex].followers + 1},
        ...defStore.slice(userindex + 1)];
   
    return newStore;

    default:
    return defStore;
   }

}