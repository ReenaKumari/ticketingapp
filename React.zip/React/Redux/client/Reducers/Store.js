import {createStore} from 'redux';
import rootReducer from './RootReducer';
import {allusers} from '../Data/UserData';
var store=createStore(rootReducer,{users:allusers});
export default store; 