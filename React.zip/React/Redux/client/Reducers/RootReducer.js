import {combineReducers} from 'redux'
import users from './UserReducer';
import contact from './ContactReducer';

var rootReducer = combineReducers({users,contact});
export default rootReducer;