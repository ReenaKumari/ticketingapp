import React from 'react';
export class BasicComponent extends React.Component{
    render(){
        return <h1> Hello to React JS! </h1>

    }
}