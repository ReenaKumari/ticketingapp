import React from 'react';

export class CourseComp extends React.Component{
    render(){
        return <h1>{this.props.coursename}</h1>
    }
}