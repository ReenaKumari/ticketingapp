// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import {BlogComp} from './ComposiableComp';
import {CourseComp} from './ConfigurableComp';
import {ListofCourses} from './ListofCourses';
import {ButtonComp} from './ButtonComp';
import ButtonList from './ListofButtons';
import DynamicListofButtons from './DynamicListofButtons';
import PostsComp from './PostComp'


ReactDOM.render(<PostsComp/>,document.getElementById("content"));