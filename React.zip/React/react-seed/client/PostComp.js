import React from 'react';
import ReactDOM from 'react-dom';

export default class PostsComp extends React.Component{
    componentWillMount(){
        this.state = {posts:[]}
    }
    componentDidMount(){
        $.get('https://jsonplaceholder.typicode.com/posts',(response)=>{
            console.log(response);
            this.setState({posts:response});
        })
    }
    render(){
        var postsToBeCreated = this.state.posts.map((post)=>{
            return <li key={post.id}>{post.title}</li>
        })
        return <div><h1>Posts</h1>
        <ul> {postsToBeCreated }</ul>
        </div>
    }
}