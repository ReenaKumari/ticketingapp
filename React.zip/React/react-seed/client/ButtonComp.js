import React from 'react';

export  class ButtonComp extends React.Component{
   // constructor(){
    //    super();
       // this.state ={count:100};
   // }

   constructor(props){
       super(props);
       this.state = {count:this.props.initialcount}
   }
    HandleClick(){
        this.setState({count:this.state.count + 1});
    }
    render(){
        return <p><button className="btn btn-primary" onClick={this.HandleClick.bind(this)}>{this.state.count}</button></p>
    }
}