import React from 'react';
import {CourseComp} from './ConfigurableComp';
export class ListofCourses extends React.Component{
    constructor(){
        super();
        this.course1 ="Angular JS";
    }
    render(){
        return <div>
    <CourseComp coursename={this.course1}/>
    <CourseComp coursename="React JS"/>
    <CourseComp coursename="REDUX"/>
    <CourseComp coursename="ZoneJS"/>
    <CourseComp coursename="KnockoutJS"/>
    </div>
    }

}