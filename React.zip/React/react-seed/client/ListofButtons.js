import React from 'react';
import ButtonComp from './ButtonComp'

export default class ButtonList extends React.Component{
    constructor(){
        super();
    }
    render(){
        return <div>
            <ButtonComp initialcount={40}/>
            <ButtonComp initialcount={120}/>
            <ButtonComp initialcount={780}/>
            <ButtonComp initialcount={2850}/>
            </div>
    }
}