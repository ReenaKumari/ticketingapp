import React from 'react';
 class FormComp extends React.Component{
            render(){
                return <form>
                            <h1>Form Component:</h1>
                            Insert Comment here:<input type="text"/>
                            <input type="button" value="Insert"/>
                    </form>
            }
        }

         class CommentComp extends React.Component{
            render(){
                return <div>
                            <b>Learning JSX</b> <br/>
                            <b>Seems Inserting</b> <br/>
                    </div>
            }
        }

       export  class BlogComp extends React.Component{
            render(){
                return <div>
                    <FormComp/>
                    <CommentComp/>
                    </div>
            }
        }