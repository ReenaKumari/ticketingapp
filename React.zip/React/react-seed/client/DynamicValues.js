import React from 'react';
import {ButtonComp} from './ButtonComp'

export default class DynamicValues extends React.Component{
    constructor(){
        super();
        this.state = {list:[10,20,30,40,50]};
    }
    render(){

        var list_of_Buttons = this.state.list.map((b)=>{
            return <ButtonComp initialcount={b}/>
        })
        return <div>
            {list_of_Buttons}
            </div>
    }
}