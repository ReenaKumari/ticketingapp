import React from 'react';
import ReactDOM from 'react-dom';
import {ButtonComp} from './ButtonComp'

export default class DynamicListofButtons extends React.Component{
    constructor(){
        super();
      
    }

    AddButtonsHandler(){
        //get the value from text box
        var textvalue = ReactDOM.findDOMNode(this.refs.nag).value;
        //set state by creating newstate
        var newstate = [...this.state.list,textvalue];
        this.setState({list:newstate});
    }
    componentWillMount(){
        console.log("component Will Mount Called");
          this.state = {list:[10,20,30,40,50]};
    }
        componentDidMount(){
            console.log("component Did Mount Called");
        }
        shouldComponentUpdate(){
            console.log("shouldComponentUpdate Called");
            if(this.state.list.length <7){
                     return true; // if it's false UI will not update
            }
                    else{
                        return false;
                    }
        }
    render(){

        var list_of_Buttons = this.state.list.map((b,index)=>{
            return <ButtonComp initialcount={b} key={index}/>
        })
        return <div>

            Enter Number Here: <input type="text" ref="nag"/><input type="button" value="Add" 
            className="btn btn-success" onClick={this.AddButtonsHandler.bind(this)}/>
            <br/>
            {list_of_Buttons}
            </div>
    }
}