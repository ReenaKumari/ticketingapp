var gutil = require('gulp-util');
var minimist = require('minimist');

exports.paths = {
    sass: './app/resource/scss/*.scss',
    src: './app/',
    html: './app/**/*.html',
    images: './app/resource/img/**/*',
    data: './app/resource/data/**/*',
    www: './www/'
};

var knownOptions = {
    string: 'mode',
    default: {
        mode: 'dev'
    }
};
exports.options = minimist(process.argv.slice(2), knownOptions);


/**
 *  Common implementation for an error handler of a Gulp plugin
 */
exports.errorHandler = function(title) {
    'use strict';

    return function(err) {
        gutil.log(gutil.colors.red('[' + title + ']'), err.toString());
        this.emit('end');
    };
};
