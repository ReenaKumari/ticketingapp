var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');


// Watch for changes in files
gulp.task('watch', function() {
    // Watch .js files
    gulp.watch('app/**/*.js', ['scripts']);
    // Watch .scss files
    gulp.watch(['scss/**/*.scss', 'app/**/*.scss'], ['sass']);
    //Watch .html files
    gulp.watch('app/**/*.html', ['minify-html']);
    // Watch image files
    gulp.watch('app/resource/img/**/*', ['images']);
    // Watch json files
    gulp.watch('app/resource/data/**/*.json', ['data']);
});