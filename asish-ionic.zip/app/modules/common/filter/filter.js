(function (angular) {
    "use strict";
    commonService.filter('groupBy', function ($parse) {
        return
        /*_.memoize(function (items, field) {
            var getter = $parse(field);
            return _.groupBy(items, function (item) {
                return getter(item);
            });
        })*/
        ;
    }).filter('capitalize', function () {
        return function (input, scope) {
            if (input != null)
                input = input.toLowerCase();
            return input.substring(0, 1).toUpperCase() + input.substring(1);
        }
    }).filter('customDateFormat', function customDateFormat($filter) {
        return function (text, format) {
            //var tempdate = new Date(text.replace(/-/g, "/"));
            if(text){
                if(format){
                 return $filter('date')(new Date(text), format);
                }else{
                    return $filter('date')(text, "dd/MM/yyyy");
                }
            }
            return '';
                
        }
    }).filter('sumByKey', function() {
        return function(data, key) {
            if (typeof(data) === 'undefined' || typeof(key) === 'undefined') {
                return 0;
            }
            var sum = 0;
            for (var i = data.length - 1; i >= 0; i--) {
                sum += parseInt(data[i][key]);
            }
            return sum;
        };
    });

} (window.angular));
