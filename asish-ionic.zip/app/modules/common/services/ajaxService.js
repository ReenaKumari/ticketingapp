'use strict';
/**
 * @ngdoc service
 * @name appModule.ajaxService
 * @requires $http
 * @requires $q
 * @returns {object} ajaxService ajaxService Object
 * @description
 * ajaxService handles all the ajax service requests in the app.
 */
commonService.factory('ajaxService', ['$http', '$q', '$window', 'AppConfig', '$rootScope', '$httpParamSerializerJQLike',
    function ($http, $q, $window, AppConfig, $rootScope, $httpParamSerializerJQLike) {

        var appMode = AppConfig.env.mode || '';
        var hostApiObj = AppConfig.api[appMode];
        var hostApiUrl = hostApiObj.serviceReqPath || '';

        var requestObj = {
            method: 'GET',
            url: '',
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache,no-store',
                'Access-Control-Allow-Origin': '*',
                'Accept': 'application/json',
            },
            cache: false,
            statusText: 'loading...',
            timeout: 90000
        };

        var ajaxService = {
            getViewStubs: function (keyName) {
                if (!keyName) {
                    return $q.reject();
                }
                var viewStubsObj = AppConfig.viewStubs;
                var reqObj = {
                    url: viewStubsObj.serviceReqPath + viewStubsObj[keyName]
                };
                return genericGetCall(reqObj);
            },

            authenticateUser: function (inputObj) {
                var reqObj = {
                    url: hostApiObj.serviceReqPath + hostApiObj.authenticate
                };
                reqObj.data = $httpParamSerializerJQLike(inputObj);
                return genericPostCall(reqObj);
            },
            logoutUser: function name() {
                var reqObj = {
                    //                    url: hostApiUrl + hostApiObj.logout
                    url: hostApiObj.serviceReqPath + hostApiObj.logout
                };
                return genericPostCall(reqObj);
            },
            getUserDetails: function (inputObj) {
                var reqObj = {
                    url: hostApiUrl + hostApiObj.authenticate
                };
                reqObj.params = inputObj;
                return genericGetCall(reqObj);
            },
            skipMeterOption: function () {
                var reqObj = {
                    url: 'data/skip-meter-option.json'
                };
                return genericGetCall(reqObj);
            },
            getReadCycles: function () {
                var reqObj = {
                    url: hostApiUrl + hostApiObj.readcycles
                };
                return genericGetCall(reqObj);
            },
            syncMeterRead: function (inputObj) {
                var reqObj = {
                    url: hostApiUrl + hostApiObj.meterread
                };
                reqObj.data = inputObj;
                return genericPostCall(reqObj);
            },
            getPropertyList: function (inputObj) {
                var reqObj = {
                    url: hostApiUrl + hostApiObj.readcycleproperties
                };
                reqObj.data = $httpParamSerializerJQLike(inputObj);
                return genericPostCall(reqObj);
            },
            getDeltaReadMeters : function (inputObj) {
                var reqObj = {
                    url: hostApiUrl + hostApiObj.SyncMeterDetails
                };
                reqObj.data = $httpParamSerializerJQLike(inputObj);
                return genericPostCall(reqObj);
            },
            meterComments : function (inputObj) {
                var reqObj = {
                    url: hostApiUrl + hostApiObj.meterComment
                };
                reqObj.data = $httpParamSerializerJQLike(inputObj);
                return genericPostCall(reqObj);
            },
            propertyHazardComment : function (inputObj) {
                var reqObj = {
                    url: hostApiUrl + hostApiObj.propertyHazard
                };
                reqObj.data = $httpParamSerializerJQLike(inputObj);
                return genericPostCall(reqObj);
            },
            syncHazardAndMeterComment : function(inputObj){
                var api =(inputObj.apitype === AppConfig.APITYPE.METERCOMMENT) ?  hostApiObj.meterComment :  hostApiObj.propertyHazard;
                var reqObj = {
                    url: hostApiUrl +  api
                };
                inputObj.apiparam = JSON.parse(inputObj.apiparam);
                reqObj.data = $httpParamSerializerJQLike(inputObj.apiparam);
                return genericPostCall(reqObj);
            }


        };
        function genericGetCall(reqObj) {
            reqObj.method = 'GET';
            var reqObjExt = angular.extend({}, requestObj, reqObj);
            return $http(reqObjExt);
        }

        function genericPostCall(reqObj) {
            reqObj.method = (appMode != 'static') ? 'POST' : 'GET';
            var reqObjExt = angular.extend({}, requestObj, reqObj);
            return $http(reqObjExt);
        }
        function genericDeleteCall(reqObj) {
            reqObj.method = 'DELETE';
            var reqObjExt = angular.extend({}, requestObj, reqObj);
            return $http(reqObjExt);
        }
        return ajaxService;
    }]);

