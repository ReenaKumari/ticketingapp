'use strict';

//App specific configurations
commonService.constant('AppConstant', {
        SYNC_INTERVAL: 10,// should be set in minutes
        SYNC_INTERVAL_COUNTER: 1800,// should be set in seconds
        LAST_SYNC_PUSH : 'LAST_SYNC_PUSH',
        SYNC_IN_PROGRESS : 'SYNC_IN_PROGRESS'
});
